import champ
import numpy


def main():

    #create random planes
    test_hs=[]
    np.random.seed(0)


    # print test_hs
    # print test_int_dict

    plt.close()
    ax=plot_2d_domains(test_int_dict)
    plt.show()
    return 1

if __name__=='__main__':

    exit(main())