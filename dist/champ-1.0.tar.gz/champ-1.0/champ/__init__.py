'''
CHAMP (Convex Hull of Admissible Modularity Partitions) implementation
'''
from .champ import find_intersection
from .plot_domains import plot_2d_domains

